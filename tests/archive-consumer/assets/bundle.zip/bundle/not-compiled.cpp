#error an archive member is data, not a source of this package
